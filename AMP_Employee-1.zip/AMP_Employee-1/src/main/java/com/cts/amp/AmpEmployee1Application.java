package com.cts.amp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmpEmployee1Application {

	public static void main(String[] args) {
		SpringApplication.run(AmpEmployee1Application.class, args);
	}

}
