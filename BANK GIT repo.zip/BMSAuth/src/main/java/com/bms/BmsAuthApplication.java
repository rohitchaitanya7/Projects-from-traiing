package com.bms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BmsAuthApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(BmsAuthApplication.class, args);
	}

}
