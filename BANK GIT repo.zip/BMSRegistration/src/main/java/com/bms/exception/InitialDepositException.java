package com.bms.exception;

@SuppressWarnings("serial")
public class InitialDepositException extends Exception {
	
		public InitialDepositException(String msg) {
			// TODO Auto-generated constructor stub
			super(msg);
		}
}
