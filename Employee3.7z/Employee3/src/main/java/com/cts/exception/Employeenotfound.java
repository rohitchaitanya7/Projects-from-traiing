package com.cts.exception;

@SuppressWarnings("serial")
public class Employeenotfound extends Exception {
	
	public Employeenotfound(String message) {
		super(message);
	}
	

}
