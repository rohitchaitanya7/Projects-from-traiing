package com.cts.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Employee;
import com.cts.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	EmployeeService service;
	
	@GetMapping("/getAllEmployees")
	public ResponseEntity<?> getAllEmployees(){
		return new ResponseEntity<>(service.getAllEmployees(),HttpStatus.OK);
	}
	
	@PostMapping("/addEmployee")
	public ResponseEntity<?> addEmployee(@RequestBody Employee emp){
		try {
			return new ResponseEntity<>(service.addEmployee(emp),HttpStatus.OK);
		}
		catch(Exception e) {
			 return new ResponseEntity<>("Error", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/{empId}/updateEmployee")
	public ResponseEntity<?> updateEmployeeDetails(@PathVariable String empId,@RequestBody Employee emp){
		try {
			return new ResponseEntity<>(service.updateEmployeeDetails(empId, emp),HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>("Error", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/{empId}/getEmployeeById")
	public ResponseEntity<?> getEmployeeById(@PathVariable String empId){
		try {
			return new ResponseEntity<>(service.getEmployeeById(empId),HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>("Error", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
