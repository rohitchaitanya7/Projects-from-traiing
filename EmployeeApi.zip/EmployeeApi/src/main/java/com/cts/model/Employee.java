package com.cts.model;

import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "Employee")
public class Employee {
	@Id
	private String id;
	@NotBlank(message = "Employee Id is Mandatory")
	private String empId;
	@NotBlank(message = "Employee Name is Mandatory")
	private String name;
	private String dept;
	private double salary;
	private String spouseName;
	
}
