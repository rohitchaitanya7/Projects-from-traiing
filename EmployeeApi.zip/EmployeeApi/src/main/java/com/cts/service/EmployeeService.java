package com.cts.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.model.Employee;
@Service
public interface EmployeeService {
	public List<Employee> getAllEmployees();
	public Employee getEmployeeById(String id);
	public Employee updateEmployeeDetails(String id,Employee emp) throws Exception;
	public Employee addEmployee(Employee emp);
}
