package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Employee;
import com.cts.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository repo;
	
	@Override
	public List<Employee> getAllEmployees() {

		return repo.findAll();
		
	}

	@Override
	public Employee getEmployeeById(String id) {
		
		return repo.findByEmpId(id).get();
	}

	@Override
	public Employee updateEmployeeDetails(String id, Employee emp) throws Exception {
		Optional<Employee> employee=repo.findByEmpId(id); 
		if(employee.isPresent()) {
			emp.setId(employee.get().getId());
			return repo.save(emp);
		}
		throw new Exception("User Not Found");
	}

	@Override
	public Employee addEmployee(Employee emp) {
		
		return repo.save(emp);
	}

}
