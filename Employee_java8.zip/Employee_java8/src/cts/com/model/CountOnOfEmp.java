package cts.com.model;

public class CountOnOfEmp {
	
	public void countNoEmp(String s) {
	//Q2 count number of employees whose first name start with some letter
		EmployeesDetails employees = new EmployeesDetails();
		System.out.println("\n Q2 count number of employees whose first name start with some letter");
		long couunt = employees.Details().stream().filter(e->e.getName().startsWith(s)).count();
		System.out.println(couunt);
	}

}
