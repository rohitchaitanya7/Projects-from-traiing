package cts.com.model;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Maxsalary m = new Maxsalary();
		m.empSortNameSalary();
		
		CountOnOfEmp c = new CountOnOfEmp();
		c.countNoEmp("c");
		
		MapDepToEmployees e = new MapDepToEmployees();
		e.mapDepToEmp();

	}

}
