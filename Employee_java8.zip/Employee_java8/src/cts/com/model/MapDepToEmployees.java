package cts.com.model;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MapDepToEmployees {
	// Q1Dp-id : list of employees
	public void mapDepToEmp() {
		EmployeesDetails employee = new EmployeesDetails();
		System.out.println(" \n Dp-id : list of employees");
		Map<String, List<Employee>> sortemp = employee.Details().stream().collect(Collectors.groupingBy(Employee::getDepartment));
		//System.out.println(sortemp);
		
		sortemp.forEach((k,v) -> System.out.println(k +":"+ v));
	}

}
