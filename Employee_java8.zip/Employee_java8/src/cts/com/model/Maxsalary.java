package cts.com.model;

import java.util.Comparator;

public class Maxsalary {
	//Q3 create a list of employees and sort them based on name and than sort ok based of salary
		public void empSortNameSalary() {
	     
		EmployeesDetails employees = new EmployeesDetails();
			System.out.println("\nlist of employees and sort them based on name and than sort ok based of salary");
			Comparator<Employee> sortonname =  (e1,e2)->e1.getName().compareToIgnoreCase(e2.getName());
			Comparator<Employee> sortsalary = (s1,s2) ->Double.compare(s1.getSalary(), s2.getSalary());
			
			employees.Details().stream().sorted(sortonname.thenComparing(sortsalary))
			.forEach(employee->System.out.println(employee));

	}




}
