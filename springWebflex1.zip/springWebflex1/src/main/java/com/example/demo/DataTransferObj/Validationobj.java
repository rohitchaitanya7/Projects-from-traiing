package com.example.demo.DataTransferObj;

public class Validationobj {
		private int errorcode;
		private int input;
		private String msg;
		
		public int getErrorcode() {
			return errorcode;
		}
		public void setErrorcode(int errorcode) {
			this.errorcode = errorcode;
		}
		public int getInput() {
			return input;
		}
		public void setInput(int input) {
			this.input = input;
		}
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		
		
}
